// Keep the footer copyright current without needing a rebuild.
// The HTML ships with a hardcoded year, so this is only an enhancement —
// the page still reads correctly with JavaScript disabled.
document.addEventListener("DOMContentLoaded", function () {
  var year = document.getElementById("year");
  if (year) {
    year.textContent = String(new Date().getFullYear());
  }
});
