document.addEventListener("DOMContentLoaded", function () {
  var button = document.querySelector("[data-menu-button]");
  var menu = document.querySelector("[data-menu]");

  if (!button || !menu) return;

  button.addEventListener("click", function () {
    var isOpen = button.getAttribute("aria-expanded") === "true";
    button.setAttribute("aria-expanded", String(!isOpen));
    menu.classList.toggle("is-open", !isOpen);
  });
});
